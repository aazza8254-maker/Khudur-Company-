import type { NextConfig } from "next";

// A fully static site: `npm run build` writes plain HTML to ./out for Cloudflare Pages.
const nextConfig: NextConfig = {
  output: "export",
  trailingSlash: true,
  images: { unoptimized: true },
};

export default nextConfig;
