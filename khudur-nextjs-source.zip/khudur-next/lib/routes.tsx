import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { AboutPage } from "@/components/AboutPage";
import { ContactPage } from "@/components/ContactPage";
import { Frame } from "@/components/Frame";
import { HomePage } from "@/components/HomePage";
import { SectorPage } from "@/components/SectorPage";
import { SECTORS, SLUGS, T, type Lang, type Slug } from "./content";
import { pageMetadata } from "./seo";

/* Each language's route files are one line each: they call these with their language. */

export const home = {
  metadata: (lang: Lang): Metadata => pageMetadata(lang, "", T[lang].home_title, T[lang].home_desc),
  Page: (lang: Lang) => (
    <Frame lang={lang} current="">
      <HomePage lang={lang} />
    </Frame>
  ),
};

export const about = {
  metadata: (lang: Lang): Metadata => pageMetadata(lang, "about", T[lang].about_title, T[lang].about_desc),
  Page: (lang: Lang) => (
    <Frame lang={lang} current="about">
      <AboutPage lang={lang} />
    </Frame>
  ),
};

export const contact = {
  metadata: (lang: Lang): Metadata => pageMetadata(lang, "contact", T[lang].contact_title, T[lang].contact_desc),
  Page: (lang: Lang) => (
    <Frame lang={lang} current="contact">
      <ContactPage lang={lang} />
    </Frame>
  ),
};

type SectorParams = { params: Promise<{ slug: string }> };
const asSlug = (s: string): Slug => (SLUGS.includes(s as Slug) ? (s as Slug) : notFound());

export const sector = {
  params: () => SLUGS.map((slug) => ({ slug })),
  metadata: async (lang: Lang, { params }: SectorParams): Promise<Metadata> => {
    const slug = asSlug((await params).slug);
    const c = SECTORS[slug][lang];
    return pageMetadata(lang, slug, c.title, c.desc);
  },
  Page: async (lang: Lang, { params }: SectorParams) => {
    const slug = asSlug((await params).slug);
    return (
      <Frame lang={lang} current={slug}>
        <SectorPage lang={lang} slug={slug} />
      </Frame>
    );
  },
};
