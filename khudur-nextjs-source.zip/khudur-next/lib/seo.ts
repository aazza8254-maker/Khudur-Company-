import type { Metadata } from "next";
import { BASE_URL, EMAIL, PHONES, T, path, type Lang } from "./content";

export function pageMetadata(lang: Lang, slug: string, title: string, description: string, index = true): Metadata {
  const t = T[lang];
  const url = BASE_URL + path(lang, slug);
  return {
    metadataBase: new URL(BASE_URL),
    title,
    description,
    robots: index ? undefined : { index: false },
    alternates: index
      ? {
          canonical: url,
          languages: { en: BASE_URL + path("en", slug), ar: BASE_URL + path("ar", slug), "x-default": BASE_URL + path("en", slug) },
        }
      : undefined,
    openGraph: {
      type: "website",
      siteName: t.brand,
      title,
      description,
      url,
      locale: t.locale,
      images: [{ url: "/assets/og-image.jpg", width: 1200, height: 630 }],
    },
    twitter: { card: "summary_large_image" },
    icons: { icon: [{ url: "/assets/icon-48.png", sizes: "48x48", type: "image/png" }], apple: "/assets/icon-180.png" },
  };
}

export function orgSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "Organization",
    "@id": BASE_URL + "/#organization",
    name: T.en.brand,
    legalName: T.en.legal,
    alternateName: [T.ar.brand, T.ar.legal],
    url: BASE_URL + "/",
    logo: BASE_URL + "/assets/logo.jpg",
    image: BASE_URL + "/assets/og-image.jpg",
    email: EMAIL,
    telephone: PHONES.sudan[0].tel,
    foundingDate: "2013-04",
    description: T.en.home_desc,
    address: [{ "@type": "PostalAddress", streetAddress: "Al-Azhari", addressLocality: "Khartoum", addressCountry: "SD" }],
    contactPoint: [
      { "@type": "ContactPoint", contactType: "sales", telephone: PHONES.sudan[0].tel, areaServed: "Worldwide", availableLanguage: ["Arabic", "English"] },
    ],
  };
}
