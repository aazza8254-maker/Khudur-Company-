import data from "./content.json";

// Company wording lives in content.json (one entry per language). Edit it there.

export type Lang = "en" | "ar";
export const LANGS: Lang[] = ["en", "ar"];

export type Slug = "agriculture" | "medical" | "restaurant" | "factory" | "auto-parts" | "power-and-chemicals";
export const SLUGS = data.SLUGS as Slug[];

export type Strings = (typeof data.T)["en"];
export const T = data.T as Record<Lang, Strings>;

export interface SectorText {
  title: string;
  desc: string;
  name: string;
  card: string;
  h1: string;
  intro: string;
  imp: string;
  exp: string;
  caption: string | null;
  groups: { title: string; items: string[] }[];
  note: string | null;
}
export interface Sector {
  photo: { src: string; w: number; h: number } | null;
  en: SectorText;
  ar: SectorText;
}
export const SECTORS = data.SECTORS as unknown as Record<Slug, Sector>;

export const { BASE_URL, EMAIL, WHATSAPP, WHATSAPP_DISPLAY, PHONES } = data;

/** "/agriculture/" in English, "/ar/agriculture/" in Arabic. */
export function path(lang: Lang, slug = ""): string {
  const prefix = lang === "ar" ? "/ar" : "";
  return slug ? `${prefix}/${slug}/` : `${prefix}/`;
}

export const other = (lang: Lang): Lang => (lang === "ar" ? "en" : "ar");

export const navLabel = (lang: Lang, slug: Slug): string => T[lang].nav[slug];

/** Keep the Arabic "and" apart from a Latin brand name, so it reads in order. */
export const tidy = (text: string): string => text.replace(/و(?=[A-Za-z])/g, "و ");
