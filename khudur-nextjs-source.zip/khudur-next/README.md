# Khudur Company website

Next.js (App Router) + TypeScript + Tailwind CSS v4, exported as a static site for Cloudflare Pages.

## Edit wording, phones or the web address

Everything the site says, in English and Arabic, is in `lib/content.json`:
`T.en` / `T.ar` for page text, `SECTORS` for the six sector pages, and
`BASE_URL`, `EMAIL`, `WHATSAPP`, `PHONES` at the top. Change `BASE_URL` once the
real domain is bought. Images are in `public/assets`.

## Build

Needs Node.js 20 or newer.

```bash
npm install
npm run build
```

The finished site is written to `out/`. Upload that folder (or a zip of its
contents) to Cloudflare Pages. `npm run dev` shows a live preview while editing.

## Layout

- `app/(en)` and `app/(ar)/ar`: one short route file per page and language; `/` is English, `/ar/` Arabic.
- `lib/routes.tsx`: what each route renders and its metadata.
- `components/`: the pages (`HomePage`, `SectorPage`, `AboutPage`, `ContactPage`) and their parts. `Scene.tsx` is the hero's moving tractor.
- `scripts/postbuild.mjs`: puts the bilingual not-found page at `out/404.html`.
