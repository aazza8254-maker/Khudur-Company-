import type { ReactNode } from "react";
import { IBM_Plex_Sans_Arabic, Plus_Jakarta_Sans } from "next/font/google";
import { T, type Lang } from "@/lib/content";
import { Footer } from "./Footer";
import { Header } from "./Header";

const jakarta = Plus_Jakarta_Sans({ subsets: ["latin"], weight: ["400", "600", "700", "800"], variable: "--font-jakarta", display: "swap" });
const plex = IBM_Plex_Sans_Arabic({ subsets: ["arabic"], weight: ["400", "500", "600", "700"], variable: "--font-plex", display: "swap" });

/** The <html> document for one language. Each language group's root layout uses it. */
export function Document({ lang, children }: { lang: Lang; children: ReactNode }) {
  return (
    <html lang={lang} dir={T[lang].dir} className={`${jakarta.variable} ${plex.variable}`}>
      <body>{children}</body>
    </html>
  );
}

/** Header, main content and footer around a page. `current` is the page's slug ("" for home). */
export function Frame({ lang, current, children }: { lang: Lang; current: string; children: ReactNode }) {
  return (
    <>
      <a
        href="#main"
        className="absolute start-2 -top-16 z-100 rounded-md bg-ink px-4 py-2.5 text-white focus:top-2 focus:text-white"
      >
        {T[lang].skip}
      </a>
      <Header lang={lang} current={current} />
      <main id="main">{children}</main>
      <Footer lang={lang} current={current} />
    </>
  );
}
