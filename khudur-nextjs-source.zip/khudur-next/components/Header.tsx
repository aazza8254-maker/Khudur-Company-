"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { T, other, path, type Lang, type Slug } from "@/lib/content";
import { btn } from "./ui";

const NAV_SLUGS: Slug[] = ["agriculture", "medical", "restaurant", "factory", "auto-parts"];

export function Header({ lang, current }: { lang: Lang; current: string }) {
  const t = T[lang];
  const alt = other(lang);
  const [open, setOpen] = useState(false);
  const navRef = useRef<HTMLElement>(null);
  const toggleRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        toggleRef.current?.focus();
      }
    };
    const onClick = (e: MouseEvent) => {
      const target = e.target as Node;
      if (!navRef.current?.contains(target) && !toggleRef.current?.contains(target)) setOpen(false);
    };
    document.addEventListener("keydown", onKey);
    document.addEventListener("click", onClick);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("click", onClick);
    };
  }, [open]);

  const items: { key: string; label: string }[] = [
    ...NAV_SLUGS.map((s) => ({ key: s, label: t.nav[s] })),
    { key: "about", label: t.about },
    { key: "contact", label: t.contact },
  ];
  const link =
    "inline-flex min-h-12 items-center whitespace-nowrap px-2.5 text-base font-semibold text-text no-underline transition-colors hover:bg-sand-2 hover:text-text nav:min-h-11 nav:rounded-md nav:text-[.94rem]";
  const currentLink =
    "text-green! shadow-[inset_3px_0_0_var(--color-lime)] ps-3.5 rtl:shadow-[inset_-3px_0_0_var(--color-lime)] nav:rounded-none nav:ps-2.5 nav:shadow-[inset_0_-3px_0_var(--color-lime)]! ";

  return (
    <header className="sticky top-0 z-50 border-b border-line bg-white">
      <div className="wrap relative flex min-h-[72px] items-center justify-between gap-4">
        <Link href={path(lang)} className="block shrink-0">
          <img src="/assets/logo.jpg" width={632} height={133} alt={t.logo_alt} className="h-[42px] w-auto min-[421px]:h-[52px]" />
        </Link>
        <button
          ref={toggleRef}
          type="button"
          className="inline-flex size-[46px] cursor-pointer items-center justify-center rounded-lg border border-line bg-transparent text-ink nav:hidden"
          aria-expanded={open}
          aria-controls="site-nav"
          aria-label={t.menu}
          onClick={() => setOpen((v) => !v)}
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
            <path d="M4 7h16M4 12h16M4 17h16" />
          </svg>
        </button>
        <nav
          ref={navRef}
          id="site-nav"
          aria-label={t.menu}
          className={`${open ? "flex" : "hidden"} absolute inset-x-0 top-full max-h-[calc(100vh-72px)] flex-col items-stretch overflow-y-auto border-b border-line bg-white px-[clamp(16px,4vw,40px)] pt-2 pb-4 shadow-[0_12px_24px_rgba(16,41,31,.12)] nav:static nav:flex nav:max-h-none nav:flex-row nav:items-center nav:gap-0.5 nav:overflow-visible nav:border-0 nav:p-0 nav:shadow-none`}
        >
          {items.map((it) => (
            <Link key={it.key} href={path(lang, it.key)} aria-current={it.key === current ? "page" : undefined} className={`${link} ${it.key === current ? currentLink : ""}`} onClick={() => setOpen(false)}>
              {it.label}
            </Link>
          ))}
          <Link
            href={path(alt, current)}
            lang={alt}
            hrefLang={alt}
            title={t.lang_title}
            className={`${link} my-2 justify-center rounded-md border border-line nav:mx-2 nav:my-0`}
          >
            {t.lang_label}
          </Link>
          <Link href={path(lang, "contact")} className={`${btn("primary")} min-h-12 whitespace-nowrap nav:min-h-[42px] nav:px-4 nav:text-[.94rem]`}>
            {t.quote}
          </Link>
        </nav>
      </div>
    </header>
  );
}
