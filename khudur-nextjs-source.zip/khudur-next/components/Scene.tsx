"use client";

import { useEffect, useRef } from "react";

/* The home hero: a sun, curved field rows from the logo, and a tractor driving along the ridge. */

const RIDGE = "M-200 205C300 95 900 70 1800 190";
const BOTTOMS: [number, number][] = [[-520, -300], [-120, 90], [280, 470], [660, 830], [1010, 1160], [1340, 1470], [1640, 1780]];
const VX = 1460;
const VY = 130;

function seg(x: number): [number, number, number, number, number, number] {
  return [Math.round(VX - 0.32 * (VX - x)), 175, Math.round(x + 0.3 * (VX - x)), 345, x, 540];
}

const ROWS = BOTTOMS.map(([a, b], i) => {
  const [c1x, c1y, c2x, c2y, ex, ey] = seg(a);
  const [d1x, d1y, d2x, d2y, fx, fy] = seg(b);
  return {
    fill: i % 2 === 0 ? "#a6d62a" : "#7dbb24",
    d: `M${VX} ${VY}C${c1x} ${c1y} ${c2x} ${c2y} ${ex} ${ey}L${fx} ${fy}C${d2x} ${d2y} ${d1x} ${d1y} ${VX} ${VY}Z`,
  };
});

const RAYS = Array.from({ length: 18 }, (_, i) => i * 20);
const STALK_A: [number, number, number][] = [[4, -30, 20], [-10, -2, -22], [16, 2, 40], [-16, 28, -22], [10, 34, 40], [2, -58, 16]];
const STALK_B: [number, number, number][] = [[-4, -26, -18], [8, -2, 22], [-16, 2, -38], [14, 26, 22], [-8, 30, -38]];
const LIGHT = "#f4f6f1";
const GOLD = "#e3a21a";

export function Scene() {
  const ref = useRef<SVGSVGElement>(null);

  // Stop the tractor for visitors who prefer less motion.
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) ref.current?.pauseAnimations();
  }, []);

  return (
    <svg
      ref={ref}
      className="absolute inset-x-0 bottom-0 z-0 h-(--sh) w-full max-w-none overflow-visible rtl:-scale-x-100"
      viewBox="0 0 1600 540"
      preserveAspectRatio="xMidYMax slice"
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        <clipPath id="hill">
          <path d={`${RIDGE}L1800 560L-200 560Z`} />
        </clipPath>
      </defs>
      <g transform="translate(1040 210)">
        <g className="rays" fill={GOLD} fillOpacity=".45">
          {RAYS.map((a) => (
            <path key={a} d="M0 -205 L13 -320 L-13 -320Z" transform={`rotate(${a})`} />
          ))}
        </g>
        <circle r="185" fill={GOLD} />
      </g>
      <path fill="#2c7a35" d="M-200 165C350 40 1000 40 1800 130V400H-200Z" />
      <path fill="#1c5a2b" d={`${RIDGE}L1800 560L-200 560Z`} />
      <g clipPath="url(#hill)">
        {ROWS.map((r) => (
          <path key={r.d} fill={r.fill} d={r.d} />
        ))}
      </g>
      <g id="tractor">
        <path fill={LIGHT} d="M-42 -40h94a4 4 0 0 1 4 4v14H-42z" />
        <path fill="none" stroke={LIGHT} strokeWidth="6" strokeLinejoin="round" d="M-40 -42V-90H2l10 48" />
        <path fill={LIGHT} d="M-46 -94H8v7h-54z" />
        <path stroke={LIGHT} strokeWidth="5" strokeLinecap="round" d="M38 -40V-70" />
        <circle cx="-26" cy="-27" r="27" fill={LIGHT} />
        <circle cx="-26" cy="-27" r="11" fill={GOLD} />
        <circle cx="42" cy="-14" r="14" fill={LIGHT} />
        <circle cx="42" cy="-14" r="5" fill={GOLD} />
      </g>
      <animateMotion href="#tractor" dur="42s" repeatCount="indefinite" rotate="auto" path={RIDGE} />
      <g className="wheat" fill={GOLD} stroke={GOLD} strokeWidth="5" strokeLinecap="round">
        <path fill="none" d="M120 540C125 450 140 390 170 320" />
        {STALK_A.map(([dx, dy, r]) => (
          <ellipse key={`a${dx}${dy}`} cx={170 + dx} cy={320 + dy} rx="7" ry="17" stroke="none" transform={`rotate(${r} ${170 + dx} ${320 + dy})`} />
        ))}
        <path fill="none" d="M95 540C90 470 80 420 55 370" />
        {STALK_B.map(([dx, dy, r]) => (
          <ellipse key={`b${dx}${dy}`} cx={55 + dx} cy={370 + dy} rx="6" ry="15" stroke="none" transform={`rotate(${r} ${55 + dx} ${370 + dy})`} />
        ))}
      </g>
    </svg>
  );
}
