import { T, type Lang } from "@/lib/content";
import { orgSchema } from "@/lib/seo";
import { Cta, PageHero, SectionHead } from "./sections";
import { Bullets, JsonLd } from "./ui";

export function AboutPage({ lang }: { lang: Lang }) {
  const t = T[lang];
  const split = "wrap grid items-start gap-[clamp(28px,5vw,56px)] min-[880px]:grid-cols-2";
  return (
    <>
      <JsonLd data={orgSchema()} />
      <PageHero lang={lang} crumb={t.about} title={t.about_h1} lede={t.about_p} />

      <section className="section-y">
        <div className={split}>
          <div>
            <h2>{t.who_h}</h2>
            {t.who.map((p) => (
              <p key={p}>{p}</p>
            ))}
          </div>
          <div>
            <h2>{t.facts_h}</h2>
            <dl className="m-0 rounded-[10px] border border-line bg-white px-[22px] py-1.5">
              {t.facts.map((f) => (
                <div key={f.k} className="border-t border-line py-[13px] first:border-t-0">
                  <dt className="text-[.88rem] text-muted">{f.k}</dt>
                  <dd className="m-0 font-semibold">{f.v}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </section>

      <section className="section-y bg-sand-2">
        <div className={split}>
          <div>
            <h2>{t.mission_h}</h2>
            <p>{t.mission_p}</p>
            <Bullets items={t.mission} />
          </div>
          <div>
            <h2>{t.vision_h}</h2>
            <p>{t.vision_p}</p>
            <h2 className="mt-[1.4em]">{t.service_h}</h2>
            <p>{t.service_p}</p>
          </div>
        </div>
      </section>

      <section className="section-y">
        <div className="wrap">
          <SectionHead title={t.scope_h} lede={t.scope_p} />
          <div className="rounded-[10px] border border-line bg-white p-[26px]">
            <Bullets items={t.scope} />
          </div>
        </div>
      </section>

      <Cta lang={lang} />
    </>
  );
}
