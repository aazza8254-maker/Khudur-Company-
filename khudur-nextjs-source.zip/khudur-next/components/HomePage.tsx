import Link from "next/link";
import { BASE_URL, SLUGS, T, path, type Lang } from "@/lib/content";
import { orgSchema } from "@/lib/seo";
import { Scene } from "./Scene";
import { Cta, SectionHead, SectorCards } from "./sections";
import { Arrow, Bullets, Eyebrow, JsonLd, btn } from "./ui";

const BOARD_ICONS = [
  <path key="pin" d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21zM12 12a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z" />,
  <path key="swap" d="M4 8h14M14 4l4 4-4 4M20 16H6M10 12l-4 4 4 4" />,
  <path key="globe" d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM3 12h18M12 3c2.5 2.5 3.8 5.5 3.8 9s-1.3 6.5-3.8 9c-2.5-2.5-3.8-5.5-3.8-9S9.5 5.5 12 3z" />,
];

/** "Khudur at a glance": the founding year up top, then icon rows. */
function Board({ lang }: { lang: Lang }) {
  const t = T[lang];
  const [lead, ...rest] = t.board;
  return (
    <aside className="rounded-[14px] border border-white/15 border-t-4 border-t-wheat bg-board p-[clamp(20px,2.4vw,28px)] shadow-[0_18px_40px_#00000040]">
      <h2 className="mb-3.5 text-[.95rem] tracking-normal text-wheat">{t.board_h}</h2>
      <dl className="m-0">
        <div className="mb-1.5 border-b border-white/15 pb-4">
          <dt className="text-[.92rem] text-on-ink-muted">{lead.k}</dt>
          <dd className="m-0 text-[clamp(2.8rem,2.2rem+2vw,3.8rem)] leading-[1.05] font-extrabold tracking-[-.02em] text-wheat" dir="ltr">
            <span className="block rtl:text-right">{lead.v}</span>
          </dd>
        </div>
        {rest.map((row, i) => (
          <div key={row.k} className="relative min-h-11 py-3 ps-14">
            <dt className="text-[.86rem] leading-[1.4] text-on-ink-muted">
              <svg
                className="absolute start-0 top-3.5 size-10 rounded-full bg-white/[.07] p-2.5 text-lime"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.9"
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden="true"
                focusable="false"
              >
                {BOARD_ICONS[i]}
              </svg>
              {row.k}
            </dt>
            <dd className="m-0 text-[1.02rem] leading-[1.45] font-semibold">{row.v}</dd>
          </div>
        ))}
      </dl>
    </aside>
  );
}

/** "From your request to delivery" as a connected timeline. */
function Steps({ lang }: { lang: Lang }) {
  return (
    <ol className="m-0 grid list-none gap-0 p-0 min-[900px]:grid-cols-4 min-[900px]:gap-7">
      {T[lang].how.map((step, i, all) => (
        <li key={step.h} className="group relative ps-[68px] pb-[30px] last:pb-0 min-[900px]:ps-0 min-[900px]:pt-[66px] min-[900px]:pb-0">
          <span
            className="absolute start-0 top-0 z-1 grid size-12 place-items-center rounded-full bg-ink font-extrabold text-wheat transition-colors group-hover:bg-wheat group-hover:text-ink"
          >
            {String(i + 1).padStart(2, "0")}
          </span>
          {i < all.length - 1 && (
            <span
              aria-hidden="true"
              className="absolute start-[23px] top-12 bottom-0 w-0.5 bg-lime min-[900px]:start-12 min-[900px]:top-[23px] min-[900px]:bottom-auto min-[900px]:h-0.5 min-[900px]:w-[calc(100%-48px+28px)]"
            />
          )}
          <h3 className="mb-[.3em]">{step.h}</h3>
          <p className="m-0 text-[.97rem] text-muted">{step.p}</p>
        </li>
      ))}
    </ol>
  );
}

/** Brands as a written list, one row per category. A dot that would start a line is clipped. */
function BrandList({ lang }: { lang: Lang }) {
  return (
    <div className="overflow-hidden rounded-[10px] border border-line bg-white">
      {T[lang].src.map((group) => (
        <div key={group.label} className="grid gap-x-8 gap-y-2 border-t border-line px-[clamp(18px,3vw,32px)] py-[22px] transition-colors first:border-t-0 hover:bg-sand min-[800px]:grid-cols-[250px_1fr] min-[800px]:items-baseline">
          <h3 className="m-0 text-base text-green">{group.label}</h3>
          <ul className="m-0 flex list-none flex-wrap gap-y-1.5 overflow-hidden p-0">
            {group.brands.map((b) => (
              <li
                key={b}
                className="relative inline-flex items-center pe-[1.5em] text-[clamp(1.05rem,1rem+.3vw,1.2rem)] font-bold text-ink before:absolute before:-start-[.9em] before:top-1/2 before:-mt-[2.5px] before:size-[5px] before:rounded-full before:bg-wheat before:content-['']"
              >
                <span dir="ltr">{b}</span>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
}

export function HomePage({ lang }: { lang: Lang }) {
  const t = T[lang];
  const website = { "@context": "https://schema.org", "@type": "WebSite", name: t.brand, url: BASE_URL + path(lang), inLanguage: lang, publisher: { "@id": BASE_URL + "/#organization" } };
  return (
    <>
      <JsonLd data={orgSchema()} />
      <JsonLd data={website} />

      <section className="relative overflow-hidden bg-ink text-on-ink [--sh:max(clamp(240px,40vh,480px),33.75vw)]">
        <Scene />
        <div className="wrap relative z-1 pt-[clamp(52px,8vw,104px)] pb-[calc(var(--sh)*1.12)]">
          <div className="grid items-center gap-[clamp(32px,5vw,64px)] min-[960px]:grid-cols-[1.25fr_.75fr]">
            <div>
              <Eyebrow light>{t.hero_eyebrow}</Eyebrow>
              <h1>{t.hero_h1}</h1>
              <p className="max-w-[62ch] text-[clamp(1.05rem,1rem+.4vw,1.25rem)] text-on-ink-muted">{t.hero_p}</p>
              <div className="flex flex-wrap gap-3">
                <Link className={btn("wheat")} href={path(lang, "contact")}>
                  {t.quote} <Arrow />
                </Link>
                <a className={btn("ghost")} href="#sectors">
                  {t.hero_b2}
                </a>
              </div>
            </div>
            <Board lang={lang} />
          </div>
        </div>
      </section>

      <section className="section-y" id="sectors">
        <div className="wrap">
          <SectionHead eyebrow={t.sectors_eyebrow} title={t.sectors_h} lede={t.sectors_p} />
          <SectorCards lang={lang} slugs={SLUGS} />
        </div>
      </section>

      <section className="section-y bg-sand-2">
        <div className="wrap grid items-start gap-[clamp(28px,5vw,56px)] min-[880px]:grid-cols-2 min-[880px]:items-stretch">
          <div>
            <Eyebrow>{t.setup_eyebrow}</Eyebrow>
            <h2>{t.setup_h}</h2>
            <p className="max-w-[62ch] text-[1.1rem] text-muted">{t.setup_p}</p>
            <div className="flex flex-wrap gap-3">
              <Link className={btn("primary")} href={path(lang, "restaurant")}>
                {t.setup_a}
              </Link>
              <Link className={btn("outline")} href={path(lang, "factory")}>
                {t.setup_b}
              </Link>
            </div>
          </div>
          <div className="flex rounded-[10px] border border-line bg-white p-[26px]">
            <Bullets items={t.setup_list} className="min-[880px]:flex min-[880px]:flex-1 min-[880px]:flex-col min-[880px]:justify-evenly min-[880px]:[&>li]:mb-0" />
          </div>
        </div>
      </section>

      <section className="section-y">
        <div className="wrap">
          <SectionHead eyebrow={t.how_eyebrow} title={t.how_h} />
          <Steps lang={lang} />
        </div>
      </section>

      <section className="section-y bg-sand-2">
        <div className="wrap">
          <SectionHead eyebrow={t.src_eyebrow} title={t.src_h} lede={t.src_p} />
          <BrandList lang={lang} />
          <p className="mt-3 text-[.9rem] text-muted">{t.src_fine}</p>
        </div>
      </section>

      <Cta lang={lang} />
    </>
  );
}
