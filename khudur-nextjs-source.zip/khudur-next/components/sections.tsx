import Link from "next/link";
import type { ReactNode } from "react";
import { SECTORS, T, path, type Lang, type Slug } from "@/lib/content";
import { Arrow, Furrows, SectorIcon, btn } from "./ui";

/** The green band near the bottom of most pages. */
export function Cta({ lang, slug }: { lang: Lang; slug?: Slug }) {
  const t = T[lang];
  const href = path(lang, "contact") + (slug ? `?sector=${slug}` : "");
  return (
    <section className="no-print bg-green text-white">
      <div className="wrap flex flex-wrap items-center justify-between gap-[22px] py-10">
        <div>
          <h2 className="mb-[.2em] text-[clamp(1.4rem,1.1rem+1.2vw,2rem)]">{t.cta_h}</h2>
          <p className="m-0 text-[#e9f2e3]">{t.cta_p}</p>
        </div>
        <Link className={btn("wheat")} href={href}>
          {t.quote} <Arrow />
        </Link>
      </div>
    </section>
  );
}

export function SectorCards({ lang, slugs }: { lang: Lang; slugs: Slug[] }) {
  const t = T[lang];
  return (
    <div className="grid grid-cols-[repeat(auto-fit,minmax(min(100%,290px),1fr))] gap-[18px]">
      {slugs.map((s) => {
        const c = SECTORS[s][lang];
        return (
          <Link
            key={s}
            href={path(lang, s)}
            className="group flex flex-col rounded-[10px] border border-line bg-white p-[26px] text-inherit no-underline transition-[border-color,box-shadow] hover:border-green hover:text-inherit hover:shadow-[0_8px_24px_rgba(16,41,31,.1)]"
          >
            <SectorIcon slug={s} className="mb-3.5 size-[42px] text-green" />
            <h3>{c.name}</h3>
            <p className="flex-1 text-[.97rem] text-muted">{c.card}</p>
            <span className="inline-flex items-center gap-1.5 font-bold text-green">
              {t.read_more} <Arrow />
            </span>
          </Link>
        );
      })}
    </div>
  );
}

export function SectionHead({ eyebrow, title, lede }: { eyebrow?: string; title: string; lede?: string }) {
  return (
    <div className="mb-[clamp(28px,4vw,44px)] max-w-[760px]">
      {eyebrow && <span className="mb-2.5 block text-[.85rem] font-bold text-green">{eyebrow}</span>}
      <h2>{title}</h2>
      {lede && <p className="max-w-[62ch] text-[1.1rem] text-muted">{lede}</p>}
    </div>
  );
}

/** Dark hero used on every page except home. */
export function PageHero({ lang, crumb, title, lede, icon, children }: { lang: Lang; crumb: string; title: string; lede: string; icon?: Slug; children?: ReactNode }) {
  const t = T[lang];
  return (
    <section className="relative overflow-hidden bg-ink text-on-ink">
      <Furrows />
      <div className="wrap relative z-1 py-[clamp(52px,8vw,104px)]">
        <nav className="mb-[18px] text-[.9rem] text-on-ink-muted" aria-label={t.home}>
          <Link href={path(lang)} className="text-on-ink hover:text-white">
            {t.home}
          </Link>
          <span className="mx-[.4em]" aria-hidden="true">
            /
          </span>
          {crumb}
        </nav>
        {icon && <SectorIcon slug={icon} className="mb-4 size-16 text-wheat" />}
        <h1>{title}</h1>
        <p className="max-w-[62ch] text-[clamp(1.05rem,1rem+.4vw,1.25rem)] text-on-ink-muted">{lede}</p>
        {children}
      </div>
    </section>
  );
}
