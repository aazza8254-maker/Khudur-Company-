import { EMAIL, T, WHATSAPP, WHATSAPP_DISPLAY, type Lang } from "@/lib/content";
import { orgSchema } from "@/lib/seo";
import { Phones } from "./Footer";
import { QuoteForm } from "./QuoteForm";
import { PageHero } from "./sections";
import { JsonLd } from "./ui";

export function ContactPage({ lang }: { lang: Lang }) {
  const t = T[lang];
  const card = "mb-[18px] rounded-[10px] border border-line bg-white p-6 [&_p]:mb-[.4em]";
  return (
    <>
      <JsonLd data={orgSchema()} />
      <PageHero lang={lang} crumb={t.contact} title={t.contact_h1} lede={t.contact_p} />
      <section className="section-y">
        <div className="wrap grid items-start gap-[clamp(28px,5vw,56px)] min-[880px]:grid-cols-2">
          <div>
            <h2>{t.form_h}</h2>
            <QuoteForm lang={lang} />
          </div>
          <div>
            <h2>{t.c_direct}</h2>
            <div className={card}>
              <h3 className="mb-[.5em]">{t.f_sudan}</h3>
              <p>{t.sudan_addr}</p>
              <p>
                {t.c_phone}:
                <br />
                <Phones />
              </p>
            </div>
            <div className={card}>
              <p>
                {t.c_wa}:{" "}
                <a className="inline-block" dir="ltr" href={`https://wa.me/${WHATSAPP}`} rel="noopener">
                  {WHATSAPP_DISPLAY}
                </a>
              </p>
            </div>
            <div className={card}>
              <h3 className="mb-[.5em]">{t.c_email}</h3>
              <p>
                <a className="inline-block" dir="ltr" href={`mailto:${EMAIL}`}>
                  {EMAIL}
                </a>
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
