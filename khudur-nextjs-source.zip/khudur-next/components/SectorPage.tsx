import Link from "next/link";
import { BASE_URL, SECTORS, SLUGS, T, path, type Lang, type Slug } from "@/lib/content";
import { Cta, PageHero, SectorCards } from "./sections";
import { Arrow, Bullets, JsonLd, btn } from "./ui";

export function SectorPage({ lang, slug }: { lang: Lang; slug: Slug }) {
  const t = T[lang];
  const data = SECTORS[slug];
  const c = data[lang];
  const others = SLUGS.filter((s) => s !== slug).slice(0, 3);
  const crumbs = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: t.home, item: BASE_URL + path(lang) },
      { "@type": "ListItem", position: 2, name: c.name, item: BASE_URL + path(lang, slug) },
    ],
  };
  const service = { "@context": "https://schema.org", "@type": "Service", name: c.name, description: c.desc, serviceType: "Import and export", areaServed: "Worldwide", provider: { "@id": BASE_URL + "/#organization" } };
  const direction = "rounded-[10px] border border-line border-s-4 border-s-wheat bg-white px-6 py-[22px]";

  return (
    <>
      <JsonLd data={crumbs} />
      <JsonLd data={service} />
      <PageHero lang={lang} crumb={c.name} title={c.h1} lede={c.intro} icon={slug}>
        <Link className={btn("wheat")} href={`${path(lang, "contact")}?sector=${slug}`}>
          {t.quote} <Arrow />
        </Link>
      </PageHero>

      <section className="section-y">
        <div className="wrap">
          <h2>{t.sec_dirs}</h2>
          <div className="mb-11 grid grid-cols-[repeat(auto-fit,minmax(min(100%,290px),1fr))] gap-[18px]">
            <div className={direction}>
              <h3 className="mb-[.4em]">{t.imp}</h3>
              <p className="m-0 text-muted">{c.imp}</p>
            </div>
            <div className={direction}>
              <h3 className="mb-[.4em]">{t.exp}</h3>
              <p className="m-0 text-muted">{c.exp}</p>
            </div>
          </div>

          {data.photo && (
            <figure className="mx-0 mt-0 mb-7 overflow-hidden rounded-[10px] border border-line bg-white" style={{ maxWidth: data.photo.w }}>
              <img src={`/assets/${data.photo.src}`} width={data.photo.w} height={data.photo.h} alt={c.caption ?? ""} loading="lazy" className="max-h-[520px] w-full object-cover" />
              {c.caption && <figcaption className="px-4 py-2.5 text-[.9rem] text-muted">{c.caption}</figcaption>}
            </figure>
          )}

          <h2>{t.sec_wwd}</h2>
          <div className="grid grid-cols-[repeat(auto-fit,minmax(min(100%,290px),1fr))] gap-[18px]">
            {c.groups.map((g) => (
              <div key={g.title} className="rounded-[10px] border border-line bg-white p-[26px]">
                <h3 className="text-ink">{g.title}</h3>
                <Bullets items={g.items} />
              </div>
            ))}
          </div>

          {c.note && (
            <div className="mt-6 rounded-[10px] border border-notice-line bg-notice px-[22px] py-[18px]">
              <p className="m-0">{c.note}</p>
            </div>
          )}
        </div>
      </section>

      <section className="section-y bg-sand-2">
        <div className="wrap">
          <h2>{t.other_sectors}</h2>
          <SectorCards lang={lang} slugs={others} />
        </div>
      </section>

      <Cta lang={lang} slug={slug} />
    </>
  );
}
