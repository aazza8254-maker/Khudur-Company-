import type { ReactNode } from "react";
import type { Slug } from "@/lib/content";
import { tidy } from "@/lib/content";

type Variant = "primary" | "wheat" | "ghost" | "outline";

// Each variant sets its own border colour, so no two border-colour classes compete.
const VARIANTS: Record<Variant, string> = {
  primary: "border-transparent bg-green text-white hover:bg-green-dark hover:text-white",
  wheat: "border-transparent bg-wheat text-ink hover:bg-wheat-light hover:text-ink",
  ghost: "border-current bg-transparent text-on-ink hover:bg-white/10 hover:text-on-ink",
  outline: "border-green bg-transparent text-green hover:bg-green hover:text-white",
};

/** Class list for a button-styled link or button. */
export const btn = (variant: Variant = "primary") =>
  `inline-flex min-h-[46px] cursor-pointer items-center justify-center gap-2 rounded-lg border-2 px-5 py-2.5 font-bold no-underline transition-colors ${VARIANTS[variant]}`;

export function Arrow() {
  return (
    <svg className="size-4 shrink-0 rtl:-scale-x-100" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M5 12h14M13 6l6 6-6 6" />
    </svg>
  );
}

const ICONS: Record<Slug, string> = {
  agriculture:
    '<circle cx="14" cy="34" r="8"/><circle cx="14" cy="34" r="2.5"/><circle cx="37" cy="37" r="5"/><path d="M6 27v-7h14l3-10h9l3 13h6a2 2 0 0 1 2 2v9h-2M22 34h10M23 20h13M38 23v-9"/>',
  medical: '<rect x="6" y="9" width="36" height="26" rx="3"/><path d="M24 15v14M17 22h14M17 41h14M24 35v6"/>',
  restaurant: '<path d="M13 22a7 7 0 0 1 1.5-13.8A10 10 0 0 1 33.5 8.2 7 7 0 0 1 35 22v8H13zM13 36h22M16 42h16"/><path d="M20 24v6M28 24v6"/>',
  factory: '<path d="M5 42V20l11 7v-7l11 7V9h9l1 18 6 1v14zM5 42h38"/><path d="M12 35h4M22 35h4M32 35h4"/>',
  "auto-parts":
    '<circle cx="24" cy="24" r="7"/><path d="M24 5v6M24 37v6M5 24h6M37 24h6M10.6 10.6l4.2 4.2M33.2 33.2l4.2 4.2M10.6 37.4l4.2-4.2M33.2 14.8l4.2-4.2"/><circle cx="24" cy="24" r="13.5"/>',
  "power-and-chemicals": '<path d="M27 4 11 27h11l-2 17 17-24H25z"/>',
};

export function SectorIcon({ slug, className = "" }: { slug: Slug; className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 48 48"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
      dangerouslySetInnerHTML={{ __html: ICONS[slug] }}
    />
  );
}

/** Curved field rows taken from the company logo, used behind page heroes. */
export function Furrows() {
  return (
    <svg className="pointer-events-none absolute inset-x-0 bottom-0 h-[72%] w-full rtl:-scale-x-100" viewBox="0 0 1200 400" preserveAspectRatio="none" fill="none" aria-hidden="true">
      <path d="M-20 400C250 250 620 170 1220 150" stroke="#8cc21f" strokeOpacity=".2" strokeWidth="2" />
      <path d="M100 400C360 270 700 210 1220 205" stroke="#8cc21f" strokeOpacity=".17" strokeWidth="2" />
      <path d="M280 400C500 300 780 260 1220 262" stroke="#8cc21f" strokeOpacity=".14" strokeWidth="2" />
      <path d="M480 400C660 335 860 310 1220 318" stroke="#e3a21a" strokeOpacity=".2" strokeWidth="2" />
    </svg>
  );
}

/** A list with small lime squares. */
export function Bullets({ items, className = "" }: { items: string[]; className?: string }) {
  return (
    <ul className={`m-0 list-none p-0 ${className}`}>
      {items.map((item) => (
        <li key={item} className="relative mb-[.55em] ps-[26px] before:absolute before:start-0.5 before:top-[.62em] before:size-2.5 before:rounded-[2px] before:bg-lime before:content-['']">
          {tidy(item)}
        </li>
      ))}
    </ul>
  );
}

export function Eyebrow({ children, light = false }: { children: ReactNode; light?: boolean }) {
  return <span className={`mb-2.5 block text-[.85rem] font-bold ${light ? "text-wheat" : "text-green"}`}>{children}</span>;
}

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`rounded-[10px] border border-line bg-white p-[26px] ${className}`}>{children}</div>;
}

export function JsonLd({ data }: { data: object }) {
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }} />;
}
