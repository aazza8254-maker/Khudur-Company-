import Link from "next/link";
import { EMAIL, PHONES, SLUGS, T, other, path, type Lang } from "@/lib/content";

export function Phones({ className = "" }: { className?: string }) {
  return (
    <>
      {PHONES.sudan.map((p, i) => (
        <span key={p.tel}>
          {i > 0 && <br />}
          <a className={`inline-block [unicode-bidi:isolate] ${className}`} dir="ltr" href={`tel:${p.tel}`}>
            {p.label}
          </a>
        </span>
      ))}
    </>
  );
}

export function Footer({ lang, current }: { lang: Lang; current: string }) {
  const t = T[lang];
  const alt = other(lang);
  const h2 = "mb-[.8em] text-base tracking-normal text-on-ink";
  const a = "text-on-ink no-underline hover:text-white hover:underline";
  const li = "inline-flex min-h-[34px] items-center";
  return (
    <footer className="bg-ink pt-[52px] pb-7 text-[.95rem] text-on-ink-muted">
      <div className="wrap">
        <div className="grid grid-cols-[repeat(auto-fit,minmax(min(100%,230px),1fr))] gap-8">
          <div>
            <h2 className={h2}>{t.f_sudan}</h2>
            <address className="mb-4 not-italic">{t.sudan_addr}</address>
            <p>
              <Phones className={a} />
            </p>
            <p>
              <a className={`inline-block ${a}`} dir="ltr" href={`mailto:${EMAIL}`}>
                {EMAIL}
              </a>
            </p>
          </div>
          <div>
            <h2 className={h2}>{t.f_sectors}</h2>
            <ul className="m-0 list-none p-0">
              {SLUGS.map((s) => (
                <li key={s}>
                  <Link className={`${li} ${a}`} href={path(lang, s)}>
                    {t.nav[s]}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h2 className={h2}>{t.f_company}</h2>
            <ul className="m-0 list-none p-0">
              <li>
                <Link className={`${li} ${a}`} href={path(lang, "about")}>
                  {t.about}
                </Link>
              </li>
              <li>
                <Link className={`${li} ${a}`} href={path(lang, "contact")}>
                  {t.quote}
                </Link>
              </li>
              <li>
                <Link className={`${li} ${a}`} href={path(alt, current)} lang={alt} hrefLang={alt}>
                  {t.lang_label}
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-[34px] border-t border-white/15 pt-[18px] text-[.88rem]">
          <p className="m-0">
            &copy; 2026 {t.legal}. {t.rights}
          </p>
        </div>
      </div>
    </footer>
  );
}
