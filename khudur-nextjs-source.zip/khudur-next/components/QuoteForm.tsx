"use client";

import { useEffect, useRef, useState, type FormEvent } from "react";
import { EMAIL, SECTORS, SLUGS, T, WHATSAPP, type Lang } from "@/lib/content";
import { btn } from "./ui";

type Field = "name" | "contact" | "details";
type Direction = "import" | "export" | "both";

/* The site is static, so a request is sent through the visitor's own WhatsApp or email app. */
export function QuoteForm({ lang }: { lang: Lang }) {
  const t = T[lang];
  const [values, setValues] = useState({ name: "", contact: "", company: "", country: "", sector: SLUGS[0] as string, direction: "import" as Direction, details: "" });
  const [errors, setErrors] = useState<Record<Field, boolean>>({ name: false, contact: false, details: false });
  const [status, setStatus] = useState("");
  const refs = { name: useRef<HTMLInputElement>(null), contact: useRef<HTMLInputElement>(null), details: useRef<HTMLTextAreaElement>(null) };

  // A sector or direction chosen elsewhere on the site arrives in the address.
  useEffect(() => {
    const q = new URLSearchParams(window.location.search);
    const sector = q.get("sector");
    const direction = q.get("direction");
    setValues((v) => ({
      ...v,
      sector: sector && [...SLUGS, "other"].includes(sector) ? sector : v.sector,
      direction: direction === "import" || direction === "export" || direction === "both" ? direction : v.direction,
    }));
  }, []);

  const set = (key: keyof typeof values, value: string) => {
    setValues((v) => ({ ...v, [key]: value }));
    if (key in errors && value.trim()) setErrors((e) => ({ ...e, [key]: false }));
  };

  const sectorName = (s: string) => (s === "other" ? t.s_other : SECTORS[s as keyof typeof SECTORS][lang].name);
  const directionName: Record<Direction, string> = { import: t.d_import, export: t.d_export, both: t.d_both };
  const clean = (label: string) => label.replace(/\s*\(.*\)/, "").replace(/[?؟]$/, "");

  const message = () =>
    [
      t.form_intro,
      ...(
        [
          [t.l_name, values.name],
          [t.l_company, values.company],
          [t.l_country, values.country],
          [t.l_contact, values.contact],
          [t.l_sector, sectorName(values.sector)],
          [t.l_direction, directionName[values.direction]],
          [t.l_details, values.details],
        ] as [string, string][]
      )
        .filter(([, v]) => v.trim())
        .map(([label, v]) => `${clean(label)}: ${v.trim()}`),
    ].join("\n");

  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const bad: Record<Field, boolean> = { name: !values.name.trim(), contact: !values.contact.trim(), details: !values.details.trim() };
    setErrors(bad);
    const first = (["name", "contact", "details"] as Field[]).find((k) => bad[k]);
    if (first) {
      refs[first].current?.focus();
      return;
    }
    const via = (e.nativeEvent as SubmitEvent).submitter?.getAttribute("value") ?? "whatsapp";
    const text = message();
    if (via === "email") {
      window.location.href = `mailto:${EMAIL}?subject=${encodeURIComponent(t.form_subject)}&body=${encodeURIComponent(text)}`;
    } else {
      window.open(`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(text)}`, "_blank", "noopener");
    }
    setStatus(t.form_done);
  };

  const label = "mb-1.5 block p-0 font-semibold";
  const input = (bad = false) =>
    `min-h-12 w-full rounded-lg border bg-white px-3 py-2.5 text-base text-text focus:border-green focus:outline-3 focus:outline-offset-1 focus:outline-wheat ${bad ? "border-error" : "border-[#8b958e]"}`;
  const error = "mt-[5px] mb-0 text-[.92rem] font-semibold text-error";

  return (
    <form noValidate onSubmit={submit} className="rounded-[10px] border border-line bg-white p-[clamp(20px,3vw,32px)]">
      <div className="grid gap-x-4 min-[620px]:grid-cols-2">
        <div className="mb-[18px]">
          <label className={label} htmlFor="f-name">{t.l_name}</label>
          <input ref={refs.name} id="f-name" type="text" autoComplete="name" required aria-invalid={errors.name} aria-describedby="e-name" className={input(errors.name)} value={values.name} onChange={(e) => set("name", e.target.value)} />
          {errors.name && <p className={error} id="e-name">{t.req_name}</p>}
        </div>
        <div className="mb-[18px]">
          <label className={label} htmlFor="f-contact">{t.l_contact}</label>
          <input ref={refs.contact} id="f-contact" type="text" autoComplete="tel" required aria-invalid={errors.contact} aria-describedby="e-contact" className={input(errors.contact)} value={values.contact} onChange={(e) => set("contact", e.target.value)} />
          {errors.contact && <p className={error} id="e-contact">{t.req_contact}</p>}
        </div>
      </div>
      <div className="grid gap-x-4 min-[620px]:grid-cols-2">
        <div className="mb-[18px]">
          <label className={label} htmlFor="f-company">{t.l_company}</label>
          <input id="f-company" type="text" autoComplete="organization" className={input()} value={values.company} onChange={(e) => set("company", e.target.value)} />
        </div>
        <div className="mb-[18px]">
          <label className={label} htmlFor="f-country">{t.l_country}</label>
          <input id="f-country" type="text" autoComplete="country-name" className={input()} value={values.country} onChange={(e) => set("country", e.target.value)} />
        </div>
      </div>
      <div className="mb-[18px]">
        <label className={label} htmlFor="f-sector">{t.l_sector}</label>
        <select id="f-sector" className={input()} value={values.sector} onChange={(e) => set("sector", e.target.value)}>
          {[...SLUGS, "other"].map((s) => (
            <option key={s} value={s}>{sectorName(s)}</option>
          ))}
        </select>
      </div>
      <fieldset className="mx-0 mb-[18px] border-0 p-0">
        <legend className={label}>{t.l_direction}</legend>
        <div className="flex flex-wrap gap-x-5 gap-y-2">
          {(["import", "export", "both"] as Direction[]).map((d) => (
            <label key={d} className="inline-flex min-h-11 cursor-pointer items-center gap-2 font-medium">
              <input type="radio" name="direction" value={d} checked={values.direction === d} onChange={() => set("direction", d)} className="size-5 accent-green" />
              {directionName[d]}
            </label>
          ))}
        </div>
      </fieldset>
      <div className="mb-[18px]">
        <label className={label} htmlFor="f-details">{t.l_details}</label>
        <span className="mb-1.5 block text-[.88rem] text-muted" id="h-details">{t.h_details}</span>
        <textarea ref={refs.details} id="f-details" required aria-invalid={errors.details} aria-describedby="h-details e-details" className={`${input(errors.details)} min-h-[130px] resize-y`} value={values.details} onChange={(e) => set("details", e.target.value)} />
        {errors.details && <p className={error} id="e-details">{t.req_details}</p>}
      </div>
      <div className="flex flex-wrap gap-3">
        <button className={btn("primary")} type="submit" value="whatsapp">{t.send_wa}</button>
        <button className={btn("outline")} type="submit" value="email">{t.send_mail}</button>
      </div>
      <p className="mt-3 text-[.9rem] text-muted">{t.form_note}</p>
      <p className="mt-3.5 mb-0 font-semibold text-green empty:hidden" role="status">{status}</p>
    </form>
  );
}
