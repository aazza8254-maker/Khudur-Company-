import { T } from "@/lib/content";
import { btn } from "./ui";

/** One bilingual page, served by Cloudflare Pages for any unknown address. */
export function NotFound() {
  const en = T.en;
  const ar = T.ar;
  return (
    <section className="bg-ink text-on-ink">
      <div className="wrap py-[clamp(52px,8vw,104px)]">
        <h1>{en.nf_title}</h1>
        <p className="max-w-[62ch] text-[1.15rem] text-on-ink-muted">{en.nf_p}</p>
        <p className="max-w-[62ch] text-[1.15rem] text-on-ink-muted" lang="ar" dir="rtl">
          {ar.nf_p}
        </p>
        <div className="flex flex-wrap gap-3">
          <a className={btn("wheat")} href="/">
            {en.nf_b}
          </a>
          <a className={btn("ghost")} href="/ar/" lang="ar">
            {ar.nf_b}
          </a>
        </div>
      </div>
    </section>
  );
}
