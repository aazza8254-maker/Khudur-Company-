import type { ReactNode } from "react";
import { Document } from "@/components/Frame";
import "../globals.css";

export default function ArabicLayout({ children }: { children: ReactNode }) {
  return <Document lang="ar">{children}</Document>;
}
