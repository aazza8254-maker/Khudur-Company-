import { home } from "@/lib/routes";

export const metadata = home.metadata("ar");
export default function Page() {
  return home.Page("ar");
}
