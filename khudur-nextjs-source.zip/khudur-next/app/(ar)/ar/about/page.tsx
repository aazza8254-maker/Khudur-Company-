import { about } from "@/lib/routes";

export const metadata = about.metadata("ar");
export default function Page() {
  return about.Page("ar");
}
