import { contact } from "@/lib/routes";

export const metadata = contact.metadata("ar");
export default function Page() {
  return contact.Page("ar");
}
