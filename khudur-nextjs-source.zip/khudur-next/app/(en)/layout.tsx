import type { ReactNode } from "react";
import { Document } from "@/components/Frame";
import "../globals.css";

export default function EnglishLayout({ children }: { children: ReactNode }) {
  return <Document lang="en">{children}</Document>;
}
