import type { Metadata } from "next";
import { Frame } from "@/components/Frame";
import { NotFound } from "@/components/NotFound";
import { T } from "@/lib/content";
import { pageMetadata } from "@/lib/seo";

// Copied to /404.html by scripts/postbuild.mjs.
export const metadata: Metadata = pageMetadata("en", "", T.en.nf_title, T.en.nf_p, false);
export default function Page() {
  return (
    <Frame lang="en" current="">
      <NotFound />
    </Frame>
  );
}
