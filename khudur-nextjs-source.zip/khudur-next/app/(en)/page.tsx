import { home } from "@/lib/routes";

export const metadata = home.metadata("en");
export default function Page() {
  return home.Page("en");
}
