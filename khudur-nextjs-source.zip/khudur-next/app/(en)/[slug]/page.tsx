import { sector } from "@/lib/routes";

type Props = { params: Promise<{ slug: string }> };

export const dynamicParams = false;
export const generateStaticParams = sector.params;
export const generateMetadata = (props: Props) => sector.metadata("en", props);
export default function Page(props: Props) {
  return sector.Page("en", props);
}
