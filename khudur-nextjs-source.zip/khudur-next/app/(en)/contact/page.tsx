import { contact } from "@/lib/routes";

export const metadata = contact.metadata("en");
export default function Page() {
  return contact.Page("en");
}
