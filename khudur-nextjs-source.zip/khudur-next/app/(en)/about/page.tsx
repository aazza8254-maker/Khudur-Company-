import { about } from "@/lib/routes";

export const metadata = about.metadata("en");
export default function Page() {
  return about.Page("en");
}
