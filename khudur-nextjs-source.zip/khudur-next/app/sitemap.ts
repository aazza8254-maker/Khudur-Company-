import type { MetadataRoute } from "next";
import { BASE_URL, LANGS, SLUGS, path } from "@/lib/content";

export const dynamic = "force-static";

export default function sitemap(): MetadataRoute.Sitemap {
  const slugs = ["", ...SLUGS, "about", "contact"];
  return LANGS.flatMap((lang) =>
    slugs.map((slug) => ({
      url: BASE_URL + path(lang, slug),
      priority: slug === "" ? 1 : slug === "about" || slug === "contact" ? 0.6 : 0.8,
      alternates: { languages: { en: BASE_URL + path("en", slug), ar: BASE_URL + path("ar", slug) } },
    })),
  );
}
