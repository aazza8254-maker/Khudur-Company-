// Cloudflare Pages serves /404.html for unknown paths. Next writes our bilingual
// not-found page to /page-not-found/, so copy it into place after each build.
import { copyFileSync, existsSync, rmSync } from "node:fs";

const from = "out/page-not-found/index.html";
if (!existsSync(from)) {
  console.error(`postbuild: ${from} is missing`);
  process.exit(1);
}
copyFileSync(from, "out/404.html");
// Drop the source copy and Next's own fallback pages, so only /404.html is served.
for (const dir of ["out/page-not-found", "out/404", "out/_not-found"]) rmSync(dir, { recursive: true, force: true });
console.log("postbuild: wrote out/404.html");
